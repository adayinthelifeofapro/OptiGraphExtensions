define("content-graph/ContentGraphCmsModule", [
  // dojo
  "dojo/_base/declare",
  // dijit
  "dijit/Destroyable",
  // epi
  "epi/_Module",
  "epi/dependency",
  "epi/routes",
  // content-graph
  "content-graph/ContentGraphCommandProvider",
  "content-graph/SynchronizeCommand"
],
  function (
    // dojo
    declare,
    // dijit
    Destroyable,
    // epi
    _Module,
    dependency,
    routes,
    // content-graph
    ContentGraphCommandProvider,
    SynchronizeCommand
  ) {

    // module:
    //      content-graph/ContentGraphModule
    // summary:
    //      Optimizely ContentGraphCmsModule.
    // tags:
    //      public

    return declare([_Module, Destroyable], {

      _settings: null,
      _timeInterval: 5000,
      // =======================================================================
      // Public, overrided stubs
      // =======================================================================

      constructor: function (/*Object*/settings) {
        this._settings = settings;
      },

      initialize: function () {
        // summary:
        //      Initialize module
        // tags:
        //      public, extensions

        this.inherited(arguments);

        var registry = this.resolveDependency("epi.storeregistry");
        registry.create("epi-contentgraph.contentindexing", this._getRestPath("contentindexing"));

        if(!this._settings.enableSynchronizeMenu) { return; }

        var command = new SynchronizeCommand();
        var commandregistry = dependency.resolve("epi.globalcommandregistry");
        commandregistry.registerProvider("epi.cms.publishmenu", new ContentGraphCommandProvider(command));

        this._scheduleSyncStatusUpdate(command);
      },

      _scheduleSyncStatusUpdate: function(command) {
        var me = this;
        command.updateSyncStatus()
        .then(function(success) {
          if(success) {
            setTimeout(function() {
              me._scheduleSyncStatusUpdate(command);
            }, me._timeInterval);
          }
          //if the first status check fails (401 error for example when the user session expires), stop checking
          //to avoid spamming 401 errors to server
        });
      },

      _getRestPath: function (/*String*/name) {
        // summary:
        //      Get Content Graph store REST path
        // name: [String]
        //      The current store name
        // tags:
        //      private

        return routes.getRestPath({
          moduleArea: "Optimizely.ContentGraph.Cms.NetCore",
          storeName: name
        });
      }
    });
  });
