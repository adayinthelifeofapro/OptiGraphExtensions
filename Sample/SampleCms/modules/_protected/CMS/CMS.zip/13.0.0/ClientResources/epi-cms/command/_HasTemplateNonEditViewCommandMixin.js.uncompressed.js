define("epi-cms/command/_HasTemplateNonEditViewCommandMixin", [
    "dojo/_base/declare",
    // Parent class
    "epi-cms/command/_NonEditViewCommandMixin"
], function (declare, 
// Parent class
_NonEditViewCommandMixin) {
    return declare([_NonEditViewCommandMixin], {
        _viewChanged: function (type, args, data, context) {
            this.inherited(arguments);
            var hasTemplate = (!context || (context.hasTemplate && !!context.previewUrl));
            this.set("isAvailable", hasTemplate);
        }
    });
});
