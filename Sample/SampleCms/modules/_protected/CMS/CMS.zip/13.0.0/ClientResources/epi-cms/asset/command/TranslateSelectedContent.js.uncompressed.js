define("epi-cms/asset/command/TranslateSelectedContent", [
    "dojo/_base/declare",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons.translate",
    "epi/shell/command/_Command",
    "epi/shell/command/_SelectionCommandMixin",
    "epi-cms/command/TranslateContent",
    "dojo/_base/lang"
], function (declare, resources, _Command, _SelectionCommandMixin, TranslateContent, lang) {
    return declare([_Command, TranslateContent, _SelectionCommandMixin], {
        // tags:
        //      internal xproduct
        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: resources.label,
        // executingLabel: [public] String
        //      The action text of the command when executing to be used in visual elements.
        executingLabel: resources.executinglabel,
        // tooltip: [public] String
        //      The description text of the command to be used in visual elements.
        tooltip: resources.title,
        // category: [const] String
        //      A category which provides a hint about how the command could be displayed.
        category: "context",
        constructor: function (params) {
            lang.mixin(this, params);
        },
        _getNormalizedModel: function () {
            // summary:
            //      Gets a normalized model in order to handle the different possible inputs.
            // tags:
            //      private
            var model = this._getSingleSelectionData();
            if (model) {
                var content = model.contentData || model;
                return {
                    content: content,
                    language: model.languageContext ||
                        model.missingLanguageBranch || {
                        language: content.currentLanguageBranch && content.currentLanguageBranch.languageId
                    }
                };
            }
        }
    });
});
