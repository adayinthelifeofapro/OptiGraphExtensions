define("epi-cms/activity/SimpleActivityFeed", [
    "require",
    "dojo/_base/declare",
    // Parent class and mixins
    "dijit/_WidgetBase"
], function (moduleRequire, declare, 
// Parent class and mixins
_WidgetBase) {
    return declare([_WidgetBase], {
        buildRendering: function () {
            this.inherited(arguments);
            moduleRequire([
                "epi-cms-react/components/activity-feed-widget",
                "xstyle/css!epi-cms-react/components/activity-feed-widget.css"
            ], function (ActivityFeedWidget) {
                this.activityFeed = new ActivityFeedWidget();
                this.domNode.appendChild(this.activityFeed.domNode);
            }.bind(this));
        }
    });
});
