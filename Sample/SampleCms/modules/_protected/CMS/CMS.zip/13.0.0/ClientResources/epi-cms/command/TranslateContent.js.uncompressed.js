define("epi-cms/command/TranslateContent", [
    "require",
    "dojo",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Deferred",
    "dojo/when",
    "dojo/topic",
    "epi/dependency",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons.translate",
    "epi/shell/command/_Command",
    "epi-cms/contentediting/viewmodel/CreateLanguageBranchViewModel",
    "epi-cms/contentediting/ContentActionSupport"
], function (moduleRequire, dojo, declare, lang, Deferred, when, topic, dependency, resources, _Command, CreateLanguageBranchViewModel, ContentActionSupport) {
    return declare([_Command], {
        // tags:
        //      internal xproduct
        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: resources.label,
        // iconClass: [readonly] String
        //		The icon class of the command to be used in visual elements.
        iconClass: "epi-iconLanguage",
        // executingLabel: [public] String
        //      The action text of the command when executing to be used in visual elements.
        executingLabel: resources.executinglabel,
        // tooltip: [public] String
        //      The description text of the command to be used in visual elements.
        tooltip: resources.title,
        // category: [const] String
        //      A category which provides a hint about how the command could be displayed.
        category: "context",
        // createLanguageBranchViewModel: [private] CreateLanguageBranchViewModel
        //      The view model for creating a language branch.
        createLanguageBranchViewModel: null,
        // contentDataStore: [readonly] Object
        //      The content data store.
        contentDataStore: null,
        initialize: function () {
            if (!this.contentDataStore) {
                this.contentDataStore = dependency
                    .resolve("epi.storeregistry")
                    .get("epi.cms.contentdata");
            }
            if (!this.createLanguageBranchViewModel) {
                this.createLanguageBranchViewModel =
                    new CreateLanguageBranchViewModel();
            }
        },
        save: function (settings) {
            if (!settings) {
                return;
            }
            var def = new Deferred();
            var _saveSuccessHandler = this.createLanguageBranchViewModel.on("saveSuccess", function (result) {
                result["languageBranch"] = settings.languageBranch;
                this._onSaveSuccess(result);
                def.resolve();
                _saveSuccessHandler.remove();
            }.bind(this));
            var _saveErrorHandler = this.createLanguageBranchViewModel.on("saveError", function () {
                this._onSaveError();
                def.reject();
                _saveErrorHandler.remove();
            }.bind(this));
            when(this.createLanguageBranchViewModel.update(settings))
                .then(function () {
                this.createLanguageBranchViewModel.save(settings.isMachineTranslation, settings.rejectWithErrorCallback);
            }.bind(this));
            return def.promise;
        },
        _execute: function () {
            // summary:
            //      Publishes a change view request to change to the create language branch view.
            // tags:
            //      protected
            if (typeof this.executeDelegate === "function") {
                this.executeDelegate(this.model);
            }
            else {
                this._showTranslateContentDialog();
            }
        },
        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected
            this.initialize();
            var model = this._getNormalizedModel();
            if (model) {
                when(this.contentDataStore.get(model.content.contentLink)).then(function (content) {
                    var missingLanguageBranch = model.content.missingLanguageBranch;
                    model = lang.mixin(model, { content: content });
                    var isAvailable = model.content.isLocalizable;
                    var canExecute = (!missingLanguageBranch || missingLanguageBranch.isPreferredLanguageAvailable) &&
                        model.content.supportedLanguages &&
                        model.content.supportedLanguages.some(function (item) {
                            return item.commonDraftLink === null;
                        }) &&
                        ContentActionSupport.isActionAvailable(model.content, ContentActionSupport.action.Create, ContentActionSupport.providerCapabilities.Create, true) &&
                        model.language.isPreferredLanguageAvailable !== false;
                    if (model &&
                        typeof model.content.canTranslateContent ===
                            "function") {
                        // Check if the model allows the current content to be translated.
                        var canTranslate = model.content.canTranslateContent();
                        isAvailable = isAvailable && canTranslate;
                        canExecute = canExecute && canTranslate;
                    }
                    // Command is available if there is a translation needed.
                    this.set("isAvailable", !!isAvailable);
                    // Command is executable if the current user has sufficient privilege to translate and
                    // that the preferred language is configured to be available for the current content.
                    this.set("canExecute", !!canExecute);
                }.bind(this));
            }
        },
        _getNormalizedModel: function () {
            // summary:
            //      Gets a normalized model in order to handle the different possible inputs.
            // tags:
            //      private
            var model = this.model;
            if (model) {
                var content = model.contentData || model;
                return {
                    content: content,
                    language: model.languageContext ||
                        model.missingLanguageBranch || {
                        language: content.currentLanguageBranch && content.currentLanguageBranch.languageId
                    }
                };
            }
        },
        _showTranslateContentDialog: function () {
            var model = this._getNormalizedModel();
            if (!model) {
                return;
            }
            var deferred = new Deferred();
            if (!model.content.supportedLanguages) {
                when(this.contentDataStore.get(model.content.contentLink))
                    .then(function (content) {
                    model = lang.mixin(model, { content: content });
                })
                    .always(function () {
                    deferred.resolve();
                });
            }
            else {
                // Immediately resolve it since it already exists in the model.
                deferred.resolve();
            }
            when(deferred.promise).then(function () {
                moduleRequire([
                    "epi-cms-react/components/translate-content-widget",
                    "xstyle/css!epi-cms-react/components/translate-content-widget.css"
                ], function (TranslateContentWidget) {
                    var translateContentWidget = new TranslateContentWidget({
                        model: model,
                        translateContentCommand: this
                    });
                    translateContentWidget.render();
                }.bind(this));
            }.bind(this));
        },
        _onSaveSuccess: function (result) {
            // summary:
            //    Handle save success event from the model.
            //
            // tags:
            //    private
            try {
                var url = new URL(window.location.href);
                if (!url) {
                    throw new Error("Error while setting content language");
                }
                var urlToNavigate = [
                    url.protocol,
                    "//",
                    url.host,
                    url.pathname,
                    "?language=",
                    result.languageBranch,
                    "#context=epi.cms.contentdata:///",
                    result.contentLink,
                    "&viewsetting=viewlanguage:///",
                    result.languageBranch
                ].join("");
                var contentUrl = new URL(urlToNavigate);
                if (url.href === contentUrl.href) {
                    topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + result.contentLink }, {
                        sender: this,
                        forceContextChange: result.changeContext,
                        forceReload: true
                    });
                }
                else {
                    topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + result.contentLink }, {
                        sender: this,
                        forceContextChange: result.changeContext,
                        forceReload: true
                    });
                    setTimeout(function () {
                        window.location.assign(contentUrl);
                    }, 0);
                }
                // Stop further execution
                return;
            }
            catch (err) {
                console.error(err.message);
                // Fallback to window.location reload?
                window.location.reload();
            }
        },
        _onSaveError: function () {
            // summary:
            //    Handle save error event from the model.
            //
            // tags:
            //    private
            topic.publish("/epi/cms/action/showerror");
        }
    });
});
