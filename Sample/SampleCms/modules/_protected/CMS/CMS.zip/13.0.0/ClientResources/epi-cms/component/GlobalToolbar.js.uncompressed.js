require({cache:{
'url:epi-cms/component/templates/GlobalToolbar.html':"﻿<div class=\"dijit epi-globalToolbar\" role=\"toolbar\" tabIndex=\"${tabIndex}\" data-dojo-attach-point=\"containerNode\">\n    <div class=\"epi-toolbarLeading epi-toolbarGroup\" data-dojo-attach-point=\"leadingGroupContainerNode\">\n        <div class=\"epi-toolbarLeading epi-toolbarGroup epi-toolbarSubGroup\"\n            data-dojo-attach-point=\"topLeadingContainerNode\"></div>\n        <div class=\"epi-toolbarLeading epi-toolbarGroup epi-toolbarSubGroup\"\n            data-dojo-attach-point=\"leadingContainerNode\"></div>\n    </div>\n    <div class=\"epi-toolbarCenter epi-toolbarGroup\" data-dojo-attach-point=\"centerContainerNode\"></div>\n    <div data-dojo-attach-point=\"trailingContainerNode\" class=\"epi-toolbarTrailing epi-toolbarGroup\">\n        <div class=\"epi-toolbarTrailing epi-toolbarGroup epi-toolbarSubGroup\" data-dojo-attach-point=\"trailingContainerNode\"></div>\n        <div class=\"epi-toolbarTrailing epi-toolbarGroup epi-toolbarSubGroup\" data-dojo-attach-point=\"lastTrailingContainerNode\"></div>\n    </div>\n</div>\n"}});
define("epi-cms/component/GlobalToolbar", [
    "dojo/_base/declare",
    "dojo/topic",
    "dojo/when",
    "dijit/Toolbar",
    "dijit/Viewport",
    "epi/shell/command/_CommandModelBindingMixin",
    "epi/shell/command/_WidgetCommandConsumerMixin",
    "epi/shell/command/builder/_Builder",
    "epi/shell/command/builder/MenuAssembler",
    "epi/shell/command/builder/DropDownButtonBuilder",
    "epi/shell/command/builder/ExpandoMenuBuilder",
    "epi/shell/_ContextMixin",
    "dojo/text!./templates/GlobalToolbar.html",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons"
], function (declare, topic, when, Toolbar, Viewport, _CommandModelBindingMixin, _WidgetCommandConsumerMixin, _Builder, MenuAssembler, DropDownButtonBuilder, ExpandoMenuBuilder, _ContextMixin, template, resources) {
    var ToolbarCommandModelBindingMixin = declare([_CommandModelBindingMixin], {
        postscript: function () {
            this.inherited(arguments);
            this.modelBindingMap.viewName = "modelViewName";
            this.modelBindingMap.viewContext = "modelViewContext";
        }
    });
    var _MenuBuilder = declare([_Builder], {
        _create: function (command) {
            if (command.settings.widgetInstance) {
                command.settings.widgetInstance._command = command;
                return command.settings.widgetInstance;
            }
            //Declare a new widget and add the _CommandModelBindingMixin
            var widgetPrototype = declare([command.settings.widget, ToolbarCommandModelBindingMixin]);
            //Create the new widget
            return new widgetPrototype(command.settings);
        },
        _addToContainer: function (widget, container, command) {
            if (!command || !command.settings || !command.settings.toolbarVerticalPosition) {
                return this.inherited(arguments);
            }
            var widgetContainer = document.createElement("div");
            widgetContainer.classList.add("toolbar-widget-container");
            widgetContainer.classList.add(command.settings.toolbarVerticalPosition);
            var insertIndex = this._getInsertIndex(widget, container);
            if (insertIndex === null) {
                container.appendChild(widgetContainer);
            }
            else {
                container.insertBefore(container.children[insertIndex]);
            }
            widget.placeAt(widgetContainer);
        }
    });
    var _DropDownButtonBuilder = declare([DropDownButtonBuilder], {
        _addButtonToContainer: function (container) {
            if (!this.settings.toolbarVerticalPosition) {
                return this.inherited(arguments);
            }
            var widgetContainer = document.createElement("div");
            widgetContainer.classList.add("toolbar-widget-container");
            widgetContainer.classList.add(this.settings.toolbarVerticalPosition);
            container.appendChild(widgetContainer);
            this._button.placeAt(widgetContainer);
        }
    });
    var _MenuAssembler = declare([MenuAssembler], {
        _getBuildInfo: function (command) {
            // summary:
            //      Return the builder information for a specific command based on its category property
            // tags: private
            //Get the category from the settings object instead of the command
            if (command.settings.category) {
                var i = this.configuration.length - 1;
                for (; i > 0; i--) {
                    if (this.configuration[i].category === command.settings.category) {
                        return this.configuration[i];
                    }
                }
            }
            return this.configuration[0];
        }
    });
    return declare([Toolbar, _WidgetCommandConsumerMixin, _ContextMixin], {
        // summary:
        //      A component providing the global toolbar.
        //
        // tags:
        //      internal
        templateString: template,
        commandKey: "epi.cms.globalToolbar",
        _resizeViewportHandle: null,
        postCreate: function () {
            // summary: Overridden to add buttons to the tool bar once the toolbar itself has been created.
            this.inherited(arguments);
            //Assemble the menu for the available commands
            var builder = new _MenuBuilder();
            var commentsbuilder = new _MenuBuilder({
                settings: {
                    "class": "epi-mediumButton comments-button",
                    showLabel: false
                }
            });
            var dropDownBuilder = new _DropDownButtonBuilder({
                settings: {
                    title: resources.createcontent.title,
                    "class": "epi-mediumButton epi-disabledDropdownArrow create-experience-button",
                    iconClass: "epi-iconPlus",
                    showLabel: false
                },
                hideEmptyButton: true
            });
            var assemblerConfig = [
                { category: "top-leading", builder: builder, target: this.topLeadingContainerNode },
                { category: "leading", builder: builder, target: this.leadingContainerNode },
                {
                    category: "view", builder: new ExpandoMenuBuilder({
                        optionClass: "epi-menu--inverted",
                        optionItemClass: "epi-radioMenuItem"
                    }), target: this.trailingContainerNode
                },
                { category: "create", builder: dropDownBuilder, target: this.leadingContainerNode },
                { category: "center", builder: builder, target: this.centerContainerNode },
                { category: "trailing", builder: commentsbuilder, target: this.trailingContainerNode },
                {
                    category: "compare", builder: new ExpandoMenuBuilder({
                        customClass: "compare-button",
                        optionClass: "epi-menu--inverted",
                        optionItemClass: "epi-radioMenuItem"
                    }), target: this.trailingContainerNode
                },
                { category: "last-trailing", builder: commentsbuilder, target: this.lastTrailingContainerNode }
            ];
            this.own(topic.subscribe("/epi/cms/action/togglecreatemode", function (createMode) {
                this._toggleGlobalToolbar(!createMode);
            }.bind(this)));
            this.own(topic.subscribe("/epi/shell/action/viewchanged", this._viewChanged.bind(this)));
            var assembler = new _MenuAssembler({ configuration: assemblerConfig, commandSource: this });
            assembler.build();
            this._toolbarVisibilityForViewConfiguration = {
                "epi-cms/component/Trash": this._updateToolbarVisibilityForTrashView.bind(this),
                "epi-cms/project/Overview": this._updateToolbarVisibilityForProjectView.bind(this)
            };
            when(this.getCurrentContext()).then(this.contextChanged.bind(this));
        },
        destroy: function () {
            this._resizeViewportHandle && this._resizeViewportHandle.remove();
            this._resizeViewportHandle = null;
            this.inherited(arguments);
        },
        contextChanged: function (context) {
            this._toggleGlobalToolbar(context &&
                (context.type === "epi.cms.contentdata" ||
                    context.type === "epi.cms.project"));
        },
        _resizeToolbar: function () {
            this._resizeViewportHandle && this._resizeViewportHandle.remove();
            this._resizeViewportHandle = this.defer(function () {
                Viewport.emit("resize");
                this._resizeViewportHandle = null;
            }, 150);
        },
        onCommandsChanged: function () {
            this.inherited(arguments);
            this._resizeToolbar();
        },
        _toggleGlobalToolbar: function (shouldBeVisible) {
            this.domNode.classList.toggle("dijitHidden", !shouldBeVisible);
            this._resizeToolbar();
        },
        _visibleAllToolbarAreas: function () {
            this.topLeadingContainerNode.classList.remove("dijitHidden");
            this.leadingContainerNode.classList.remove("dijitHidden");
            this.centerContainerNode.classList.remove("dijitHidden");
            this.trailingContainerNode.classList.remove("dijitHidden");
            this.lastTrailingContainerNode.classList.remove("dijitHidden");
        },
        _viewChanged: function (type, args, data) {
            this._visibleAllToolbarAreas();
            var updateToolbarVisibility = this._toolbarVisibilityForViewConfiguration[type];
            if (updateToolbarVisibility) {
                updateToolbarVisibility();
            }
            this._resizeToolbar();
        },
        _updateToolbarVisibilityForProjectView: function () {
            this.leadingContainerNode.classList.add("dijitHidden");
            this.trailingContainerNode.classList.add("dijitHidden");
            this.centerContainerNode.classList.add("dijitHidden");
        },
        _updateToolbarVisibilityForTrashView: function () {
            this.trailingContainerNode.classList.add("dijitHidden");
            this.centerContainerNode.classList.add("dijitHidden");
            this.lastTrailingContainerNode.classList.add("dijitHidden");
        }
    });
});
