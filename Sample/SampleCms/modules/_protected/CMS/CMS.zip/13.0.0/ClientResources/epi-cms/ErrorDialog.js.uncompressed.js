define("epi-cms/ErrorDialog", ["epi", "epi/shell/widget/dialog/ErrorDialog"], function (epi, ErrorDialog) {
    epi.cms = epi.cms || {};
    return epi.cms.ErrorDialog = ErrorDialog;
});
