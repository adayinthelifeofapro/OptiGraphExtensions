define("epi-cms/ContentContextHandler", [
    "dojo/_base/declare",
    "dijit/Destroyable",
    "dojo/topic",
    "require",
    "epi-cms/_ContentContextMixin"
], function (declare, Destroyable, topic, moduleRequire, _ContentContextMixin) {
    return declare([Destroyable, _ContentContextMixin], {
        // summary:
        //      Initializes content context related features.
        // tags:
        //      internal
        _contextEventManager: null,
        _contextKey: "content",
        initialize: function () {
            var _this = this;
            moduleRequire(["epi/shell/dist/contextEventManager"], function (cem) {
                _this._contextEventManager = cem.ContextEventManager;
                var unsubscribe = _this._contextEventManager.onRefresh(_this._contextKey, _this._refreshContent.bind(_this));
                _this.own({
                    destroy: unsubscribe
                });
            });
        },
        contentContextChanged: function (ctx) {
            this.inherited(arguments);
            this._publishContentEvent(ctx);
        },
        contentContextUpdated: function (ctx) {
            this.inherited(arguments);
            this._publishContentEvent(ctx);
        },
        _publishContentEvent: function (ctx) {
            // tags:
            //    private
            var payload = {
                key: ctx.key,
                version: "".concat(ctx.version),
                locale: ctx.language,
                previewUrl: ctx.previewUrl,
                displayName: ctx.displayName || ctx.name,
                contentLink: ctx.id
            };
            this._contextEventManager.change(this._contextKey, payload);
        },
        _refreshContent: function () {
            // tags:
            //    private
            topic.publish("/epi/shell/context/refreshcurrent");
        }
    });
});
