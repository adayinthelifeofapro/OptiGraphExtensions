define("epi-cms/command/ViewSettingsCommandProvider", [
    "dojo/_base/declare",
    "epi/dependency",
    "epi-cms/ApplicationSettings",
    "epi-cms/command/TogglePreviewMode",
    "epi-cms/command/ToggleViewSettings",
    "epi-cms/project/ProjectPreviewButton",
    "epi-cms/contentediting/command/LanguageSelection",
    "epi-cms/contentediting/viewmodel/LanguageSettingsModel",
    "./DeviceSelection",
    "epi-cms/component/command/_GlobalToolbarCommandProvider",
    // Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons.togglepreviewmode"
], function (declare, dependency, ApplicationSettings, TogglePreviewMode, ToggleViewSettings, ProjectPreviewButton, LanguageSelection, LanguageSettingsModel, DeviceSelection, _GlobalToolbarCommandProvider, resources) {
    return declare([_GlobalToolbarCommandProvider], {
        // summary:
        //      Provides view settings commands to the global toolbar
        // tags:
        //      internal
        postscript: function () {
            // summary:
            //      Instantiates and add the view commands.
            // tags:
            //      public
            this.inherited(arguments);
            // Needed since the global toolbar looks at the category both on the commands and on a settings object on the commands
            var settings = { category: "view" };
            this.add("commands", new TogglePreviewMode({
                settings: Object.assign({}, settings, {
                    statusMessages: {
                        active: resources.message
                    }
                }),
                category: settings.category,
                showLabel: false,
                order: 2
            }));
        }
    });
});
