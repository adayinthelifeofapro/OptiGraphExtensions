define("epi-cms/contentediting/command/BlockRemove", [
    // General application modules
    "dojo/_base/declare",
    // Parent class
    "epi-cms/contentediting/command/_ContentAreaCommand",
    "epi/i18n!epi/shell/ui/nls/episerver.shared"
], function (declare, _ContentAreaCommand, sharedResources) {
    return declare([_ContentAreaCommand], {
        // tags:
        //      internal xproduct
        name: "remove",
        label: sharedResources.action.remove,
        tooltip: sharedResources.action.remove,
        _execute: function () {
            // summary:
            //      Removes the content item.
            // tags:
            //      protected
            this.model.remove();
        },
        _onModelValueChange: function () {
            // summary:
            //      Updates canExecute after the model value has changed.
            // tags:
            //      protected
            this.set("canExecute", !!this.model && !this.model.get("readOnly"));
        }
    });
});
