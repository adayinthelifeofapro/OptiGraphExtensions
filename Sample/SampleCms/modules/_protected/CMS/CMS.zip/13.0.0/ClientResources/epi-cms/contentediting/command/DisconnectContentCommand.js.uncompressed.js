define("epi-cms/contentediting/command/DisconnectContentCommand", [
    "require",
    "dojo/_base/declare",
    "epi/shell/command/_Command",
    "epi-cms/contentediting/command/_ContentCommandBase",
    //Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentbinding.disconnectcontent"
], function (moduleRequire, declare, _Command, _ContentCommandBase, resources) {
    return declare([_ContentCommandBase], {
        // summary:
        //      Disconnect content from a content source.
        //
        // tags:
        //      internal
        name: "disconnectcontent",
        label: resources.command,
        category: _Command.CateoryMenuWithSeparator,
        // summary:
        // Model should be IContentBindable, so it should has the properties below:
        //    IContentBindable {
        //        contentBindable?: ContentBindableModel;
        //        contentTypeID: number;
        //        contentItemLocator: string[];
        //    }
        model: null,
        // onSuccess: [public] Function
        //      Function to be called when content is successfully disconnected.
        onSuccess: function () {
            // Override to add custom behavior after successfully disconnecting content.
        },
        _onModelChange: function () {
            // summary:
            //		Updates canExecute after the model has been updated.
            // tags:
            //		protected
            this.inherited(arguments);
            var canExecute = !!this.model &&
                !!this.model.contentBindable &&
                !!this.model.contentBindable.binding &&
                !this.model.readOnly
                && !!this.model.contentItemLocator;
            this.set("canExecute", canExecute);
            this.set("isAvailable", canExecute);
        },
        _execute: function () {
            moduleRequire([
                "epi-cms-react/components/show-binding-content-dialog"
            ], function (showBindingContentDialog) {
                showBindingContentDialog.showDisconnectContentDialog({
                    target: this.model.contentItemLocator,
                    sourceContentName: this.model.contentBindable.binding.name,
                    onSuccess: this.onSuccess.bind(this)
                });
            }.bind(this));
        }
    });
});
