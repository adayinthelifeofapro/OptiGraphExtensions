define("epi-cms/contentediting/DialogPositionAdjust", [
    "dojo/_base/declare",
    "dijit/Destroyable"
], function (declare, Destroyable) {
    return declare([Destroyable], {
        // summary:
        //      Adjust dialog position in case of small browser window
        // tags:
        //      internal
        _resizeObserver: null,
        destroy: function () {
            this.cleanup();
            this.inherited(arguments);
        },
        adjustDialogPosition: function (dialog, resizeHandle) {
            if (this._resizeObserver) {
                this._resizeObserver.disconnect();
            }
            resizeHandle = resizeHandle || this._resizeHandle;
            this._resizeObserver = new ResizeObserver(function () {
                resizeHandle(dialog);
            });
            this._resizeObserver.observe(dialog.domNode);
        },
        _resizeHandle: function (dialog) {
            if (!dialog.domNode) {
                return;
            }
            var dialogSize = dialog.domNode.getBoundingClientRect();
            var dialogTop = Math.round(window.innerHeight - dialogSize.height - 10) / 2;
            if (dialogTop > 0) {
                dialog.domNode.style.top = dialogTop + "px";
            }
            else {
                dialog.domNode.style.top = 0;
            }
            // for very small windows, limit the dialog height to fit within the window
            if (dialogSize.height > window.innerHeight) {
                var footerHeight = dialog.actionContainerNode.getBoundingClientRect().height;
                var titleHeight = dialog.titleBar.getBoundingClientRect().height;
                var newMaximumHeight = window.innerHeight - footerHeight - titleHeight - 10;
                if (newMaximumHeight > 0) {
                    dialog.containerNode.style.maxHeight = newMaximumHeight + "px";
                }
            }
        },
        cleanup: function () {
            if (this._resizeObserver) {
                this._resizeObserver.disconnect();
                this._resizeObserver = null;
            }
        }
    });
});
