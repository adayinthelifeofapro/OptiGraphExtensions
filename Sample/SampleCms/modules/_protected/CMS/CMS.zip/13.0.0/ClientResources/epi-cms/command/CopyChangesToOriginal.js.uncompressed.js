define("epi-cms/command/CopyChangesToOriginal", [
    "require",
    "dojo/_base/declare",
    "dojo/topic",
    "dojo/when",
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi-cms/core/ContentReference",
    "epi-cms/ApplicationSettings",
    "epi/i18n!epi/cms/nls/episerver.cms.variation.copychanges"
], function (moduleRequire, declare, topic, when, dependency, _Command, ContentReference, ApplicationSettings, resources) {
    return declare([_Command], {
        // summary:
        //      Copy changes from a variation to the original content.
        // tags:
        //      internal
        name: "CopyChangesToOriginal",
        label: resources.label,
        iconClass: "epi-iconAnglesUp",
        canExecute: false,
        isAvailable: false,
        _contentVersionStore: null,
        constructor: function () {
            // summary:
            //		Constructs the object and sets up the reference to the content version store.
            // tags:
            //		public
            var registry = dependency.resolve("epi.storeregistry");
            this._contentVersionStore = registry.get("epi.cms.contentversion");
        },
        _onModelChange: function () {
            var contentData = this.model && this.model.contentData;
            if (!ApplicationSettings.isVariationsEnabled || !contentData || !contentData.variation) {
                this.set("isAvailable", false);
                this.set("canExecute", false);
                return;
            }
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },
        _execute: function () {
            var self = this;
            when(self._contentVersionStore.executeMethod("PromoteVariation", self.model.contentLink))
                .then(function (result) {
                topic.publish("/epi/cms/content/new-version-created", { id: result.commonDraftId });
                self.set("canExecute", false);
                self._showUserMessage(resources.success.replace("{0}", self.model.contentData.variation), false);
            }, function (ex) {
                console.error("Error while copying changes from the variation to the original content: ", ex);
                var message = self._extractErrorMessage(ex);
                var agnosticContentLink = new ContentReference(self.model.contentLink).createVersionUnspecificReference();
                moduleRequire(["epi-cms-react/components/variation-copy-changes-failed-widget"], function (showCopyChangesFailedDialog) {
                    showCopyChangesFailedDialog(message, agnosticContentLink);
                });
            });
        },
        _extractErrorMessage: function (response) {
            if (response && response.responseText) {
                try {
                    var responseText = typeof response.responseText === "string" ? JSON.parse(response.responseText) : response.responseText;
                    if (responseText && responseText.message) {
                        return responseText.message;
                    }
                }
                catch (e) {
                    return response.responseText;
                }
            }
            return "";
        }
    });
});
