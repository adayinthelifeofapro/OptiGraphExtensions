define("epi-cms/contentediting/ModelPopulation", [
    // dojo
    "dojo/_base/declare",
    // epi
    "epi/shell/conversion/ObjectConverterRegistry"
], function (
// dojo
declare, 
// epi
ObjectConverterRegistry) {
    return {
        // tags:
        //      internal xproduct
        populateContentModel: function (data, metadata) {
            var props = {}, converterType, converter;
            for (var propertyName in data) {
                var propertyMetadata = metadata.getPropertyMetadata(propertyName);
                var propertyValue = data[propertyName];
                // default
                props[propertyName] = propertyValue;
                if (!propertyMetadata) {
                    continue;
                }
                if (propertyMetadata.hasSubProperties()) {
                    props[propertyName] = this.populateContentModel(propertyValue, propertyMetadata);
                }
                else {
                    // check for converter
                    converterType = propertyMetadata.customEditorSettings.converter;
                    if (converterType) {
                        converter = ObjectConverterRegistry.getConverter(converterType, "runtimeType");
                        if (converter) {
                            // bind converted value instead
                            props[propertyName] = converter.convert(converterType, "runtimeType", propertyValue);
                        }
                    }
                }
            }
            return props;
        }
    };
});
