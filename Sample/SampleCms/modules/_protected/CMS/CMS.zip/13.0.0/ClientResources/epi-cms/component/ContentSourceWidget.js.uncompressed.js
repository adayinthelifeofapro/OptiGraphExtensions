define("epi-cms/component/ContentSourceWidget", [
    "dojo/_base/declare",
    "dojo/dom-class",
    "epi-cms/asset/HierarchicalList"
], function (declare, domClass, HierarchicalList) {
    //TODO: this is a temporary widget which should be deleted or rewritten after the release!
    return declare([HierarchicalList], {
        buildRendering: function () {
            this.inherited(arguments);
            domClass.add(this.contentNode, "dijitHidden");
        }
    });
});
