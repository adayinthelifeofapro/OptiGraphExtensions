define("epi-cms/contentediting/SideBySideEditorWrapper", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dijit/focus",
    "epi-cms/contentediting/_EditorWrapperBase"
], function (declare, lang, focusUtil, _EditorWrapperBase) {
    return declare([_EditorWrapperBase], {
        // summary:
        //		This editor wrapper connects editor widgets in side-form to the system
        //
        // tags:
        //      internal
        _grabFocusOnStartEdit: true,
        _scrollIntoViewOnStartEdit: true,
        postCreate: function () {
            // summary:
            //		Post create initialization.
            // tags:
            //		protected
            this.inherited(arguments);
            if (this.editorWidget) {
                this.connect(this.editorWidget, "onChange", "_onChange");
                if (this.editorWidget.manualFocusManagement) {
                    this.connect(this.editorWidget, "onStartEdit", lang.hitch(this, function () {
                        this.set("editing", true);
                    }));
                    this.connect(this.editorWidget, "onStopEdit", lang.hitch(this, function () {
                        this.tryToStopEditing(false);
                    }));
                    this.connect(this.editorWidget, "onSetInitialValue", lang.hitch(this, function () {
                        this._lastSavedValue = this._resetValue = lang.clone(this.getEditorValue());
                    }));
                }
                else {
                    this.connect(this.editorWidget, "onFocus", lang.hitch(this, function () {
                        this._tryToStartEditing(false);
                    }));
                    this.connect(this.editorWidget, "onBlur", lang.hitch(this, function () {
                        // In form widgets onBlur event is raised before the last value change got updated. Therefore, at this point, editor widget's value is not up to date.
                        // This small timeout is for waiting for that change event to finish
                        setTimeout(lang.hitch(this, function () {
                            this.tryToStopEditing(true);
                        }), 0);
                    }));
                }
                this.connect(this.editorWidget, "onDropping", lang.hitch(this, function () {
                    this._scrollIntoViewOnStartEdit = false;
                    this._tryToStartEditing(false);
                }));
            }
        },
        contentModelChanged: function (name, oldValue, value) {
            // Always uptate the editor
            this.set("value", value);
        },
        _tryToStartEditing: function (grabFocus) {
            if (this.editing) {
                return;
            }
            this._grabFocusOnStartEdit = grabFocus;
            this.startEdit();
            this._grabFocusOnStartEdit = true;
        },
        _onChange: function (val) {
            // When using set value attribute, change shouldn't be propagated
            if (this._preventChangeEvent) {
                return;
            }
            var savedState = this.editing;
            // When this change is inside a DnD operation and not in "editing" state.
            if (this.operation && this.operation.inProgress && !this.editing) {
                this.editing = true;
                this._lastSavedValue = this._resetValue = this.value;
            }
            if (this.editorWidget.manualFocusManagement) {
                if (savedState && this.isValid()) {
                    this.save(val);
                }
            }
            else {
                this.inherited(arguments);
            }
            this.editing = savedState;
        },
        setEditorValue: function (val) {
            // summary:
            //		Set the [display] value of the edit widget
            // tags:
            //		override
            this.inherited(arguments);
            if (!val) {
                this.editorWidget.initialized = true;
            }
        },
        _setValueAttr: function (value) {
            // Make sure no change events is propagated when setting the value
            this._preventChangeEvent = true;
            this.inherited(arguments);
            this._preventChangeEvent = false;
        },
        startEdit: function () {
            // summary:
            //		Start editing.
            // tags:
            //		public
            var inheritedFunc = this.getInherited(arguments);
            if (this._grabFocusOnStartEdit) {
                var scrollEditorIntoView = function () {
                    focusUtil.focus(this.editorWidget.domNode);
                    this.editorWidget.focus();
                    this._scrollIntoViewOnStartEdit && this.editorWidget.domNode.scrollIntoView(true);
                    this._scrollIntoViewOnStartEdit = true;
                    inheritedFunc.apply(this);
                }.bind(this);
                // add small timeout here to wait tab is selected
                // also change to use native scrollIntoView instead of dojo window
                setTimeout(function () {
                    if (!this.editorWidget || !this.editorWidget.domNode) {
                        return;
                    }
                    scrollEditorIntoView();
                }.bind(this), 200);
                return;
            }
            inheritedFunc.apply(this);
        },
        stopEdit: function (implicitExit) {
            // summary:
            //		Stop editing.
            // tags:
            //		public
            this.set("value", this.getEditorValue());
            this.inherited(arguments);
        }
    });
});
