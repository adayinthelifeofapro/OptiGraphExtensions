define(
"dojox/atom/widget/nls/el/FeedEntryEditor", ({
	doNew: "[δημιουργία]",
	edit: "[τροποποίηση]",
	save: "[αποθήκευση]",
	cancel: "[ακύρωση]"
})
);
