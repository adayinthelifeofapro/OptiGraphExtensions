define("dojox/atom/widget/nls/FeedEntryEditor", { root:
//begin v1.x content
({
	doNew: "[new]",
	edit: "[edit]",
	save: "[save]",
	cancel: "[cancel]"
})
//end v1.x content
,
"ar": true,
"az": true,
"ca": true,
"cs": true,
"da": true,
"de": true,
"el": true,
"es": true,
"fi": true,
"fr": true,
"he": true,
"hu": true,
"hr": true,
"it": true,
"ja": true,
"kk": true,
"ko": true,
"nb": true,
"nl": true,
"pl": true,
"pt-pt": true,
"pt": true,
"ro": true,
"ru": true,
"sk": true,
"sl": true,
"sv": true,
"th": true,
"tr": true,
"zh": true,
"zh-tw": true
})
