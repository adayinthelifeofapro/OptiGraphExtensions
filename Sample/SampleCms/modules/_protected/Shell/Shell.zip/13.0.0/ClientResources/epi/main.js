//>>built
define("epi/main",["dojo"],function(_1){var _2=_1.getObject("epi",true);return _2;});