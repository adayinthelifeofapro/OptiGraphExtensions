define(
"dojox/atom/widget/nls/fr/FeedEntryViewer", ({
	displayOptions: "[options d'affichage]",
	title: "Titre",
	authors: "Auteurs",
	contributors: "Collaborateurs",
	id: "ID",
	close: "[fermer]",
	updated: "Mis à jour",
	summary: "Récapitulatif",
	content: "Contenu"
})
);
