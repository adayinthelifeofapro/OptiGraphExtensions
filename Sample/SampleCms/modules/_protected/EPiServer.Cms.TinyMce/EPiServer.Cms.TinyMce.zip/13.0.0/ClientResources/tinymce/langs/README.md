# tinymce-i18n

[![Deploy status)](https://img.shields.io/github/actions/workflow/status/mklkj/tinymce-i18n/deploy.yml?style=flat-square)](https://github.com/mklkj/tinymce-i18n/actions/workflows/deploy.yml)
[![jsDelivr](https://data.jsdelivr.com/v1/package/npm/tinymce-i18n/badge)](https://www.jsdelivr.com/package/npm/tinymce-i18n)
[![npm](https://img.shields.io/npm/dt/tinymce-i18n.svg?style=flat-square)](https://www.npmjs.com/package/tinymce-i18n)
[![npm](https://img.shields.io/npm/dw/tinymce-i18n.svg?style=flat-square)](https://www.npmjs.com/package/tinymce-i18n)
[![Packagist](https://img.shields.io/packagist/dt/mklkj/tinymce-i18n.svg?style=flat-square)](https://packagist.org/packages/mklkj/tinymce-i18n)

Languages for TinyMCE 4, 5, 6 and 7

https://www.tiny.cloud/get-tiny/language-packages/

## Instalation

Via npm

```bash
$ npm install tinymce-i18n
```

Via composer

```bash
$ composer require mklkj/tinymce-i18n dev-master
```
