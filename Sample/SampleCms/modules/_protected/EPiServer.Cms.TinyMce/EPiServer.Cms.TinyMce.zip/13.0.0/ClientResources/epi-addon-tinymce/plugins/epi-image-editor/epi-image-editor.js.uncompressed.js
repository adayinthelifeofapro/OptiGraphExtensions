define("epi-addon-tinymce/plugins/epi-image-editor/epi-image-editor", [
    "epi-addon-tinymce/tinymce-loader",
    "epi-cms/command/EditImage",
    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epiimageeditor"
], function (
    tinymce,
    EditImage,
    pluginResources
) {

    tinymce.PluginManager.add("epi-image-editor", function (editor) {

        var imageNode;

        function epiImageEditor() {

            // tinymce does store bookmark when opening a window but only for browser IE or inline editor
            // therefore, in general we need to store the bookmark ourselves
            var bookmark = editor.selection.getBookmark();

            function onHide() {
                editor.selection.moveToBookmark(bookmark);
                editor.fire("CloseWindow", {
                    win: null
                });
            }

            function onCallback(callbackObject, value) {
                editor.selection.moveToBookmark(bookmark);

                if (callbackObject) {
                    // Reset the width and height of the node so the image resizes properly.
                    if (callbackObject.hasAttribute("width")) {
                        callbackObject.removeAttribute("width");
                    }
                    if (callbackObject.hasAttribute("height")) {
                        callbackObject.removeAttribute("height");
                    }

                    // Apply new dimensions if they are present in the callback object
                    if (value.dimensions) {
                        if (value.dimensions.width) {
                            callbackObject.setAttribute("width", value.dimensions.width);
                        }
                        if (value.dimensions.height) {
                            callbackObject.setAttribute("height", value.dimensions.height);
                        }
                    }
                }

                editor.selection.setNode(callbackObject);
            }

            editor.fire("OpenWindow",
                {
                    win: null
                });
            EditImage.prototype.showImageEditorDialog(imageNode, onHide, onCallback);
        }

        // Register buttons
        editor.ui.registry.addToggleButton("epi-image-editor", {
            tooltip: pluginResources.title,
            onAction: epiImageEditor,
            icon: "edit-image",
            onSetup: function (buttonApi) {
                function nodeChange(e) {
                    //Prevent tool from being activated as objects represented as images.
                    var isStandardImage = e.element.tagName === "IMG" && editor.dom.getAttrib(e.element, "class").indexOf("mceItem") === -1;
                    var isImageFigure = e.element.tagName === "FIGURE" && /\bimage\b/i.test(e.element.className);
                    buttonApi.setActive(isStandardImage || isImageFigure);
                    buttonApi.setEnabled(!(!isStandardImage && !isImageFigure));

                    //Set or reset imageNode to the node cause Image Editor command enabled
                    imageNode = isStandardImage ? e.element : isImageFigure ? editor.dom.select("img", e.element)[0] : null;
                }

                // Add a node change handler, selects the button in the UI when a image is selected
                editor.on("NodeChange", nodeChange);

                return function () {
                    editor.off("NodeChange", nodeChange);
                };
            }
        });

        return {
            getMetadata: function () {
                return {
                    name: "Image Editor (epi)",
                    url: "https://www.optimizely.com"
                };
            }
        };
    });
});
